# Baraa Finance AI — ملفات مبسطة للرفع من الموبايل

ارفع جميع الملفات الستة الموجودة هنا إلى جذر مستودع GitHub (نفس المستوى)، بدون إنشاء مجلدات.

ملفات المشروع:
- app.py
- index.html
- logo.svg
- manifest.json
- requirements.txt
- render.yaml

على Render اختر Web Service:
Build Command: `pip install -r requirements.txt`
Start Command: `gunicorn app:app`

أضف متغيرات البيئة:
- GEMINI_API_KEY = مفتاح Gemini الخاص بك
- APP_PASSWORD = كلمة مرور قوية للتطبيق
- FLASK_SECRET = قيمة سرية طويلة وعشوائية
- GEMINI_MODEL = اسم نموذج Gemini المتاح لحسابك

ملاحظات:
- هذه نسخة تجريبية وليست مرتبطة بالبنك ولا تنفذ تحويلات مالية.
- الصوت يعتمد على دعم المتصفح ووجود HTTPS.
- قاعدة SQLite على استضافة مؤقتة قد تفقد بياناتها عند إعادة النشر؛ اربط PostgreSQL أو قرصاً دائماً قبل الاعتماد على بيانات حقيقية.
- لا ترفع أسراراً أو مفاتيح API إلى GitHub.
